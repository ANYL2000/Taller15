<?php
require_once '../assets/conexion/servidor.php';

$tallerista_seleccionado = $_GET['tallerista'];
 $taller_seleccionado = $_GET["taller"];
 $calendario_seleccionado = $_GET['calendario'];
 $turno_seleccionado = $_GET['turno'];
$dia_seleccionado = $_GET['dia'];
$Fecha_inicio = $_GET['fecha_inicio'];
$Fecha_final = $_GET['fecha_final'];

//echo "<script>alert('$Fecha_inicio');</script>";


date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');


if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 
}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='taller1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado';</script>";
}

if($calendario_seleccionado!=$año){
  echo "<script>
  window.location='taller1.1.php';
  </script>";
}

//$fecha_inicio_texto = $arr1[2].' de '.$m1.' del '.$arr1[0];

//echo $arr1[2].' de '.$m1.' del '.$arr1[0].' al '.$arr2[2].' de '.$m2.' del '.$arr2[0];


$con = connect($host, $port, $db_name, $db_username, $db_password);
$conexion = mysqli_connect($host, $db_username, $db_password,$db_name );
$conexion->query("SET NAMES 'utf8'");
$con->query("SET NAMES 'utf8'");

$validar_talleres = "SELECT * FROM mostrar_talleres WHERE Calendario = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'";

$filas_talleres = mysqli_query($conexion,$validar_talleres);

if(mysqli_num_rows($filas_talleres)==0){
  echo "<script type='text/javascript'>
  window.location='taller1.1.php';
  </script>";
}

while($taller = mysqli_fetch_array($filas_talleres)){
  $constancias_generadas = $taller['Constancias_generadas'];

}





if(empty($Fecha_inicio)||empty($Fecha_final)){
  echo "<script>window.location='taller1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado';</script>";

}

//convertir formato de fecha de inicio
$arr1 = explode('-', $Fecha_inicio);
$newDate1 = $arr1[2].'-'.$arr1[1].'-'.$arr1[0];


$m1 = "";
switch($arr1[1]){

  case '01':   $m1 = "Enero";     break;
  case '02':  $m1 = "Febrero";      break;
  case '03':  $m1 = "Marzo";      break;
  case '04':  $m1 = "Abril";      break;
  case '05':  $m1 = "Mayo";      break;
  case '06':  $m1 = "Junio";      break;
  case '07':  $m1 = "Julio";      break;
  case '08':  $m1 = "Agosto";      break;
  case '09':  $m1 = "Septiembre";      break;
  case '10':  $m1 = "Octubre";      break;
  case '11':   $m1 = "Noviembre";     break;
  case '12':   $m1 = "Diciembre";     break;

}

//convertir formato de fecha final
$arr2 = explode('-', $Fecha_final);
$newDate2 = $arr2[2].'-'.$arr2[1].'-'.$arr2[0];


$m2 = "";
switch($arr2[1]){

  case '01':   $m2 = "Enero";     break;
  case '02':  $m2 = "Febrero";      break;
  case '03':  $m2 = "Marzo";      break;
  case '04':  $m2 = "Abril";      break;
  case '05':  $m2 = "Mayo";      break;
  case '06':  $m2 = "Junio";      break;
  case '07':  $m2 = "Julio";      break;
  case '08':  $m2 = "Agosto";      break;
  case '09':  $m2 = "Septiembre";      break;
  case '10':  $m2 = "Octubre";      break;
  case '11':   $m2 = "Noviembre";     break;
  case '12':   $m2 = "Diciembre";     break;

}




//arreglo de id de usuarios seleccionados para las constancias

if($constancias_generadas=='No'){
$conexion->query("UPDATE mostrar_talleres SET  	Constancias_generadas='Si',Fecha_inicio='$Fecha_inicio',Fecha_final='$Fecha_final' WHERE Calendario = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'");
}


$sql = "SELECT * FROM constancias_alumnos WHERE NombreTallerista='$tallerista_seleccionado' AND NombreTaller = '$taller_seleccionado' AND Ingreso = '$calendario_seleccionado' AND Turno = '$turno_seleccionado' AND Dia = '$dia_seleccionado';";

$result = mysqli_query($conexion,$sql);


?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<header>
    <title>Talleres</title>
</header>




<link rel="stylesheet" href="../assets/css/estilo_taller1.2.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<?php include 'header_taller.php'; ?>
</head>
<body>
    


<div class="fondo">



<a class="btn btn-primary talleres" id="talleres" href="taller1.2.php?tallerista=<?php echo $tallerista_seleccionado?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>">Ir a Alumnos registrados</a>


<h1 class="titulo_taller">Constancias</h1>
<div class="taller_informacion">
<p id="subtitulo"> TALLERISTA: <p><?php echo "$tallerista_seleccionado"?></p> </p>
<p id="subtitulo">  TALLER: <p><?php echo "$taller_seleccionado"?></p> </p>
<p id="subtitulo">  CALENDARIO: <p> <?php echo "$calendario_seleccionado"?></p></p>
<p id="subtitulo">  TURNO: <p> <?php echo "$turno_seleccionado "?></p></p>
<p id="subtitulo">  DIA: <p> <?php echo " $dia_seleccionado" ?></p></p>
</div>




<table class="table-responsive">
    <thead>
<tr class="fila_principal">
<td>Folio</td>
    <td>Codigo</td>
    <td>Nombre Completo</td>
    <td>Correo</td>
    <td>Carrera</td>
    <td>PDF</td>
   
</tr>
</thead>

<tbody>


<?php  
while($fila = mysqli_fetch_array($result)){ 

?>

<tr class="filas_secundarias" id="color_filas" >
    <td ><?php echo $fila['Folio']; ?></td>
    <td><?php echo $fila['Codigo']; ?></td>
    <td><?php echo $fila['Nombre']; ?></td>
    <td><?php echo $fila['Correo']; ?></td>
    <td><?php echo $fila['Carrera']; ?></td>
    <td WIDTH="50" ><a href="constancias_pdf.php?tallerista=<?php echo $tallerista_seleccionado ?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>&id=<?php echo $fila['idUsuarios'];?>"><img src="../assets/img/pdf32.png" alt=""></a></a></td>
   
</tr>

</tbody>


<?php

}
?>


</table>

 
<?php
if(isset($_POST['btneditar'])){

    $id = $_POST['recipient_id'];
    $nombrenuevo = $_POST['recipient_nombre'];
    $carreranuevo = $_POST['recipient_carrera'];


    $conexion->query("UPDATE usuarios_talleres SET Nombre = '$nombrenuevo', Carrera= '$carreranuevo' WHERE idUsuarios= $id AND NombreTallerista = '$tallerista_seleccionado' AND 
    NombreTaller = '$taller_seleccionado' AND Ingreso = '$calendario_seleccionado'  AND Turno= '$turno_seleccionado' AND 
    Dia = '$dia_seleccionado'");



if($conexion){
    echo "<script type='text/javascript'>
    window.location='taller1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado'
    </script>";
}else{
    echo '<script>alertaeNoti("No se pudo actualizar la informacion")</script>';
}
    
   
         
        }

?>



</div>
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="../assets/js/checkboxes.js"></script>



</body>
</html>
<?php  $conexion=null; ?>